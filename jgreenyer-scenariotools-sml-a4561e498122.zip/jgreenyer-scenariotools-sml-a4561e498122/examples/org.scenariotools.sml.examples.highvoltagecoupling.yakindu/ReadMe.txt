This Project includes 
the sml specification of the HVCS 
the basic statechart 
and test files for HVCS under Yakindu

Yakindu https://www.itemis.com/en/yakindu/state-machine/
HVCS http://scenariotools.org/tutorial-automotive-high-voltage-coupling-system/