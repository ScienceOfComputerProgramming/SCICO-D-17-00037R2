/**
 * Copyright (c) 2016 Joel Greenyer and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * ScenarioTools-URL: www.scenariotools.org
 *    
 * Contributors:
 *     ScenarioTools Team - Initial API and implementation
 */
package org.scenariotools.sml.debug.launching;

public class ScenarioSimulationLaunchConfigurationKeys {

	public static final String ScenarioRunConfigurationURI = "ScenarioRunConfigurationURI";

	public static final String SystemSimulationAgentNsURI = "SystemSimulationAgentNsURI";
	public static final String SystemSimulationAgentEClassName = "SystemSimulationAgentEClassName";
	
	public static final String EnvironmentSimulationAgentNsURI = "EnvironmentSimulationAgentNsURI";
	public static final String EnvironmentSimulationAgentEClassName = "EnvironmentSimulationAgentEClassName";
	
	public static final String delayMilliseconds = "delayMilliseconds";
	public static final String startInPauseMode = "startInPauseMode";

	
}
