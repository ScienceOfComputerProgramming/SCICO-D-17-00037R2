/**
 * Copyright (c) 2016 Joel Greenyer and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * ScenarioTools-URL: www.scenariotools.org
 *    
 * Contributors:
 *     ScenarioTools Team - Initial API and implementation
 */
package org.scenariotools.sml.collaboration.serializer;

import com.google.inject.Inject;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.xtext.Action;
import org.eclipse.xtext.Parameter;
import org.eclipse.xtext.ParserRule;
import org.eclipse.xtext.serializer.ISerializationContext;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;
import org.scenariotools.sml.Alternative;
import org.scenariotools.sml.Case;
import org.scenariotools.sml.Collaboration;
import org.scenariotools.sml.Condition;
import org.scenariotools.sml.ConditionExpression;
import org.scenariotools.sml.ConstraintBlock;
import org.scenariotools.sml.FeatureAccessBindingExpression;
import org.scenariotools.sml.Interaction;
import org.scenariotools.sml.InterruptCondition;
import org.scenariotools.sml.Loop;
import org.scenariotools.sml.Message;
import org.scenariotools.sml.ModalMessage;
import org.scenariotools.sml.Parallel;
import org.scenariotools.sml.ParameterBinding;
import org.scenariotools.sml.Role;
import org.scenariotools.sml.RoleBindingConstraint;
import org.scenariotools.sml.Scenario;
import org.scenariotools.sml.SmlPackage;
import org.scenariotools.sml.TimedInterruptCondition;
import org.scenariotools.sml.TimedViolationCondition;
import org.scenariotools.sml.TimedWaitCondition;
import org.scenariotools.sml.ValueParameterExpression;
import org.scenariotools.sml.VariableBindingParameterExpression;
import org.scenariotools.sml.VariableFragment;
import org.scenariotools.sml.ViolationCondition;
import org.scenariotools.sml.WaitCondition;
import org.scenariotools.sml.WildcardParameterExpression;
import org.scenariotools.sml.collaboration.services.CollaborationGrammarAccess;
import org.scenariotools.sml.expressions.scenarioExpressions.BinaryOperationExpression;
import org.scenariotools.sml.expressions.scenarioExpressions.BooleanValue;
import org.scenariotools.sml.expressions.scenarioExpressions.Clock;
import org.scenariotools.sml.expressions.scenarioExpressions.ClockAssignment;
import org.scenariotools.sml.expressions.scenarioExpressions.ClockDeclaration;
import org.scenariotools.sml.expressions.scenarioExpressions.CollectionAccess;
import org.scenariotools.sml.expressions.scenarioExpressions.Document;
import org.scenariotools.sml.expressions.scenarioExpressions.EnumValue;
import org.scenariotools.sml.expressions.scenarioExpressions.ExpressionRegion;
import org.scenariotools.sml.expressions.scenarioExpressions.FeatureAccess;
import org.scenariotools.sml.expressions.scenarioExpressions.Import;
import org.scenariotools.sml.expressions.scenarioExpressions.IntegerValue;
import org.scenariotools.sml.expressions.scenarioExpressions.NullValue;
import org.scenariotools.sml.expressions.scenarioExpressions.OperationValue;
import org.scenariotools.sml.expressions.scenarioExpressions.ScenarioExpressionsPackage;
import org.scenariotools.sml.expressions.scenarioExpressions.StringValue;
import org.scenariotools.sml.expressions.scenarioExpressions.StructuralFeatureValue;
import org.scenariotools.sml.expressions.scenarioExpressions.TimedExpression;
import org.scenariotools.sml.expressions.scenarioExpressions.TypedVariableDeclaration;
import org.scenariotools.sml.expressions.scenarioExpressions.UnaryOperationExpression;
import org.scenariotools.sml.expressions.scenarioExpressions.VariableAssignment;
import org.scenariotools.sml.expressions.scenarioExpressions.VariableDeclaration;
import org.scenariotools.sml.expressions.scenarioExpressions.VariableValue;
import org.scenariotools.sml.expressions.serializer.ScenarioExpressionsSemanticSequencer;

@SuppressWarnings("all")
public abstract class AbstractCollaborationSemanticSequencer extends ScenarioExpressionsSemanticSequencer {

	@Inject
	private CollaborationGrammarAccess grammarAccess;
	
	@Override
	public void sequence(ISerializationContext context, EObject semanticObject) {
		EPackage epackage = semanticObject.eClass().getEPackage();
		ParserRule rule = context.getParserRule();
		Action action = context.getAssignedAction();
		Set<Parameter> parameters = context.getEnabledBooleanParameters();
		if (epackage == ScenarioExpressionsPackage.eINSTANCE)
			switch (semanticObject.eClass().getClassifierID()) {
			case ScenarioExpressionsPackage.BINARY_OPERATION_EXPRESSION:
				sequence_AdditionExpression_ConjunctionExpression_DisjunctionExpression_ImplicationExpression_MultiplicationExpression_RelationExpression(context, (BinaryOperationExpression) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.BOOLEAN_VALUE:
				sequence_BooleanValue(context, (BooleanValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.CLOCK:
				sequence_Clock(context, (Clock) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.CLOCK_ASSIGNMENT:
				sequence_ClockAssignment(context, (ClockAssignment) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.CLOCK_DECLARATION:
				sequence_ClockDeclaration(context, (ClockDeclaration) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.COLLECTION_ACCESS:
				sequence_CollectionAccess(context, (CollectionAccess) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.DOCUMENT:
				sequence_Document(context, (Document) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.ENUM_VALUE:
				sequence_EnumValue(context, (EnumValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.EXPRESSION_REGION:
				sequence_ExpressionRegion(context, (ExpressionRegion) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.FEATURE_ACCESS:
				sequence_FeatureAccess(context, (FeatureAccess) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.IMPORT:
				sequence_Import(context, (Import) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.INTEGER_VALUE:
				sequence_IntegerValue(context, (IntegerValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.NULL_VALUE:
				sequence_NullValue(context, (NullValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.OPERATION_VALUE:
				sequence_OperationValue(context, (OperationValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.STRING_VALUE:
				sequence_StringValue(context, (StringValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.STRUCTURAL_FEATURE_VALUE:
				sequence_StructuralFeatureValue(context, (StructuralFeatureValue) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.TIMED_EXPRESSION:
				sequence_TimedExpression(context, (TimedExpression) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.TYPED_VARIABLE_DECLARATION:
				sequence_TypedVariableDeclaration(context, (TypedVariableDeclaration) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.UNARY_OPERATION_EXPRESSION:
				sequence_NegatedExpression(context, (UnaryOperationExpression) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.VARIABLE_ASSIGNMENT:
				sequence_VariableAssignment(context, (VariableAssignment) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.VARIABLE_DECLARATION:
				sequence_VariableDeclaration(context, (VariableDeclaration) semanticObject); 
				return; 
			case ScenarioExpressionsPackage.VARIABLE_VALUE:
				sequence_VariableValue(context, (VariableValue) semanticObject); 
				return; 
			}
		else if (epackage == SmlPackage.eINSTANCE)
			switch (semanticObject.eClass().getClassifierID()) {
			case SmlPackage.ALTERNATIVE:
				sequence_Alternative(context, (Alternative) semanticObject); 
				return; 
			case SmlPackage.CASE:
				sequence_Case(context, (Case) semanticObject); 
				return; 
			case SmlPackage.COLLABORATION:
				sequence_Collaboration(context, (Collaboration) semanticObject); 
				return; 
			case SmlPackage.CONDITION:
				sequence_Condition(context, (Condition) semanticObject); 
				return; 
			case SmlPackage.CONDITION_EXPRESSION:
				sequence_ConditionExpression(context, (ConditionExpression) semanticObject); 
				return; 
			case SmlPackage.CONSTRAINT_BLOCK:
				sequence_ConstraintBlock(context, (ConstraintBlock) semanticObject); 
				return; 
			case SmlPackage.FEATURE_ACCESS_BINDING_EXPRESSION:
				sequence_FeatureAccessBindingExpression(context, (FeatureAccessBindingExpression) semanticObject); 
				return; 
			case SmlPackage.INTERACTION:
				sequence_Interaction(context, (Interaction) semanticObject); 
				return; 
			case SmlPackage.INTERRUPT_CONDITION:
				sequence_InterruptCondition(context, (InterruptCondition) semanticObject); 
				return; 
			case SmlPackage.LOOP:
				sequence_Loop(context, (Loop) semanticObject); 
				return; 
			case SmlPackage.MESSAGE:
				sequence_ConstraintMessage(context, (Message) semanticObject); 
				return; 
			case SmlPackage.MODAL_MESSAGE:
				sequence_ModalMessage(context, (ModalMessage) semanticObject); 
				return; 
			case SmlPackage.PARALLEL:
				sequence_Parallel(context, (Parallel) semanticObject); 
				return; 
			case SmlPackage.PARAMETER_BINDING:
				sequence_ParameterBinding(context, (ParameterBinding) semanticObject); 
				return; 
			case SmlPackage.ROLE:
				sequence_Role(context, (Role) semanticObject); 
				return; 
			case SmlPackage.ROLE_BINDING_CONSTRAINT:
				sequence_RoleBindingConstraint(context, (RoleBindingConstraint) semanticObject); 
				return; 
			case SmlPackage.SCENARIO:
				sequence_Scenario(context, (Scenario) semanticObject); 
				return; 
			case SmlPackage.TIMED_INTERRUPT_CONDITION:
				sequence_TimedInterruptCondition(context, (TimedInterruptCondition) semanticObject); 
				return; 
			case SmlPackage.TIMED_VIOLATION_CONDITION:
				sequence_TimedViolationCondition(context, (TimedViolationCondition) semanticObject); 
				return; 
			case SmlPackage.TIMED_WAIT_CONDITION:
				sequence_TimedWaitCondition(context, (TimedWaitCondition) semanticObject); 
				return; 
			case SmlPackage.VALUE_PARAMETER_EXPRESSION:
				sequence_ValueParameterExpression(context, (ValueParameterExpression) semanticObject); 
				return; 
			case SmlPackage.VARIABLE_BINDING_PARAMETER_EXPRESSION:
				sequence_VariableBindingParameterExpression(context, (VariableBindingParameterExpression) semanticObject); 
				return; 
			case SmlPackage.VARIABLE_FRAGMENT:
				sequence_VariableFragment(context, (VariableFragment) semanticObject); 
				return; 
			case SmlPackage.VIOLATION_CONDITION:
				sequence_ViolationCondition(context, (ViolationCondition) semanticObject); 
				return; 
			case SmlPackage.WAIT_CONDITION:
				sequence_WaitCondition(context, (WaitCondition) semanticObject); 
				return; 
			case SmlPackage.WILDCARD_PARAMETER_EXPRESSION:
				sequence_WildcardParameterExpression(context, (WildcardParameterExpression) semanticObject); 
				return; 
			}
		if (errorAcceptor != null)
			errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Contexts:
	 *     InteractionFragment returns Alternative
	 *     Alternative returns Alternative
	 *
	 * Constraint:
	 *     (cases+=Case cases+=Case*)
	 */
	protected void sequence_Alternative(ISerializationContext context, Alternative semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     Case returns Case
	 *
	 * Constraint:
	 *     (caseCondition=Condition? caseInteraction=Interaction)
	 */
	protected void sequence_Case(ISerializationContext context, Case semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     Collaboration returns Collaboration
	 *
	 * Constraint:
	 *     (
	 *         imports+=Import* 
	 *         domains+=[EPackage|FQN]* 
	 *         contexts+=[EPackage|FQN]* 
	 *         name=ID 
	 *         roles+=Role* 
	 *         scenarios+=Scenario*
	 *     )
	 */
	protected void sequence_Collaboration(ISerializationContext context, Collaboration semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     ConditionExpression returns ConditionExpression
	 *
	 * Constraint:
	 *     expression=Expression
	 */
	protected void sequence_ConditionExpression(ISerializationContext context, ConditionExpression semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.CONDITION_EXPRESSION__EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.CONDITION_EXPRESSION__EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getConditionExpressionAccess().getExpressionExpressionParserRuleCall_0(), semanticObject.getExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     Condition returns Condition
	 *
	 * Constraint:
	 *     conditionExpression=ConditionExpression
	 */
	protected void sequence_Condition(ISerializationContext context, Condition semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getConditionAccess().getConditionExpressionConditionExpressionParserRuleCall_1_0(), semanticObject.getConditionExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     ConstraintBlock returns ConstraintBlock
	 *
	 * Constraint:
	 *     (consider+=ConstraintMessage | ignore+=ConstraintMessage | forbidden+=ConstraintMessage | interrupt+=ConstraintMessage)*
	 */
	protected void sequence_ConstraintBlock(ISerializationContext context, ConstraintBlock semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     ConstraintMessage returns Message
	 *
	 * Constraint:
	 *     (
	 *         sender=[Role|ID] 
	 *         receiver=[Role|ID] 
	 *         modelElement=[ETypedElement|ID] 
	 *         collectionModification=CollectionModification? 
	 *         (parameters+=ParameterBinding parameters+=ParameterBinding*)?
	 *     )
	 */
	protected void sequence_ConstraintMessage(ISerializationContext context, Message semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     BindingExpression returns FeatureAccessBindingExpression
	 *     FeatureAccessBindingExpression returns FeatureAccessBindingExpression
	 *
	 * Constraint:
	 *     featureaccess=FeatureAccess
	 */
	protected void sequence_FeatureAccessBindingExpression(ISerializationContext context, FeatureAccessBindingExpression semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.FEATURE_ACCESS_BINDING_EXPRESSION__FEATUREACCESS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.FEATURE_ACCESS_BINDING_EXPRESSION__FEATUREACCESS));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getFeatureAccessBindingExpressionAccess().getFeatureaccessFeatureAccessParserRuleCall_0(), semanticObject.getFeatureaccess());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns Interaction
	 *     Interaction returns Interaction
	 *
	 * Constraint:
	 *     (fragments+=InteractionFragment* constraints=ConstraintBlock?)
	 */
	protected void sequence_Interaction(ISerializationContext context, Interaction semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns InterruptCondition
	 *     ConditionFragment returns InterruptCondition
	 *     InterruptCondition returns InterruptCondition
	 *
	 * Constraint:
	 *     conditionExpression=ConditionExpression
	 */
	protected void sequence_InterruptCondition(ISerializationContext context, InterruptCondition semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getInterruptConditionAccess().getConditionExpressionConditionExpressionParserRuleCall_2_0(), semanticObject.getConditionExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns Loop
	 *     Loop returns Loop
	 *
	 * Constraint:
	 *     (loopCondition=Condition? bodyInteraction=Interaction)
	 */
	protected void sequence_Loop(ISerializationContext context, Loop semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns ModalMessage
	 *     ModalMessage returns ModalMessage
	 *
	 * Constraint:
	 *     (
	 *         strict?='strict'? 
	 *         (monitored?='monitored'? expectationKind=ExpectationKind)? 
	 *         sender=[Role|ID] 
	 *         receiver=[Role|ID] 
	 *         modelElement=[ETypedElement|ID] 
	 *         collectionModification=CollectionModification? 
	 *         (parameters+=ParameterBinding parameters+=ParameterBinding*)?
	 *     )
	 */
	protected void sequence_ModalMessage(ISerializationContext context, ModalMessage semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns Parallel
	 *     Parallel returns Parallel
	 *
	 * Constraint:
	 *     (parallelInteraction+=Interaction parallelInteraction+=Interaction*)
	 */
	protected void sequence_Parallel(ISerializationContext context, Parallel semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     ParameterBinding returns ParameterBinding
	 *
	 * Constraint:
	 *     bindingExpression=ParameterExpression
	 */
	protected void sequence_ParameterBinding(ISerializationContext context, ParameterBinding semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.BINDING_CONSTRAINT__BINDING_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.BINDING_CONSTRAINT__BINDING_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getParameterBindingAccess().getBindingExpressionParameterExpressionParserRuleCall_0(), semanticObject.getBindingExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     RoleBindingConstraint returns RoleBindingConstraint
	 *
	 * Constraint:
	 *     (role=[Role|ID] bindingExpression=BindingExpression)
	 */
	protected void sequence_RoleBindingConstraint(ISerializationContext context, RoleBindingConstraint semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.ROLE_BINDING_CONSTRAINT__ROLE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.ROLE_BINDING_CONSTRAINT__ROLE));
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.BINDING_CONSTRAINT__BINDING_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.BINDING_CONSTRAINT__BINDING_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getRoleBindingConstraintAccess().getRoleRoleIDTerminalRuleCall_0_0_1(), semanticObject.eGet(SmlPackage.Literals.ROLE_BINDING_CONSTRAINT__ROLE, false));
		feeder.accept(grammarAccess.getRoleBindingConstraintAccess().getBindingExpressionBindingExpressionParserRuleCall_2_0(), semanticObject.getBindingExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     Role returns Role
	 *
	 * Constraint:
	 *     ((static?='static' | multiRole?='multi')? type=[EClass|ID] name=ID)
	 */
	protected void sequence_Role(ISerializationContext context, Role semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     Scenario returns Scenario
	 *
	 * Constraint:
	 *     (
	 *         singular?='singular'? 
	 *         kind=ScenarioKind 
	 *         name=ID 
	 *         (optimizeCost?='optimize' | cost=DOUBLE)? 
	 *         (contexts+=[EClass|ID] contexts+=[EClass|ID]*)? 
	 *         roleBindings+=RoleBindingConstraint* 
	 *         ownedInteraction=Interaction
	 *     )
	 */
	protected void sequence_Scenario(ISerializationContext context, Scenario semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns TimedInterruptCondition
	 *     TimedConditionFragment returns TimedInterruptCondition
	 *     TimedInterruptCondition returns TimedInterruptCondition
	 *
	 * Constraint:
	 *     timedConditionExpression=TimedExpression
	 */
	protected void sequence_TimedInterruptCondition(ISerializationContext context, TimedInterruptCondition semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.TIMED_CONDITION_FRAGMENT__TIMED_CONDITION_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.TIMED_CONDITION_FRAGMENT__TIMED_CONDITION_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getTimedInterruptConditionAccess().getTimedConditionExpressionTimedExpressionParserRuleCall_3_0(), semanticObject.getTimedConditionExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns TimedViolationCondition
	 *     TimedConditionFragment returns TimedViolationCondition
	 *     TimedViolationCondition returns TimedViolationCondition
	 *
	 * Constraint:
	 *     timedConditionExpression=TimedExpression
	 */
	protected void sequence_TimedViolationCondition(ISerializationContext context, TimedViolationCondition semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.TIMED_CONDITION_FRAGMENT__TIMED_CONDITION_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.TIMED_CONDITION_FRAGMENT__TIMED_CONDITION_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getTimedViolationConditionAccess().getTimedConditionExpressionTimedExpressionParserRuleCall_3_0(), semanticObject.getTimedConditionExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns TimedWaitCondition
	 *     TimedConditionFragment returns TimedWaitCondition
	 *     TimedWaitCondition returns TimedWaitCondition
	 *
	 * Constraint:
	 *     (strict?='strict'? requested?='eventually'? timedConditionExpression=TimedExpression)
	 */
	protected void sequence_TimedWaitCondition(ISerializationContext context, TimedWaitCondition semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     ParameterExpression returns ValueParameterExpression
	 *     ValueParameterExpression returns ValueParameterExpression
	 *
	 * Constraint:
	 *     value=Expression
	 */
	protected void sequence_ValueParameterExpression(ISerializationContext context, ValueParameterExpression semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.VALUE_PARAMETER_EXPRESSION__VALUE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.VALUE_PARAMETER_EXPRESSION__VALUE));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getValueParameterExpressionAccess().getValueExpressionParserRuleCall_0(), semanticObject.getValue());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     ParameterExpression returns VariableBindingParameterExpression
	 *     VariableBindingParameterExpression returns VariableBindingParameterExpression
	 *
	 * Constraint:
	 *     variable=VariableValue
	 */
	protected void sequence_VariableBindingParameterExpression(ISerializationContext context, VariableBindingParameterExpression semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.VARIABLE_BINDING_PARAMETER_EXPRESSION__VARIABLE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.VARIABLE_BINDING_PARAMETER_EXPRESSION__VARIABLE));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getVariableBindingParameterExpressionAccess().getVariableVariableValueParserRuleCall_1_0(), semanticObject.getVariable());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns VariableFragment
	 *     VariableFragment returns VariableFragment
	 *
	 * Constraint:
	 *     (expression=TypedVariableDeclaration | expression=VariableAssignment | expression=ClockDeclaration | expression=ClockAssignment)
	 */
	protected void sequence_VariableFragment(ISerializationContext context, VariableFragment semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns ViolationCondition
	 *     ConditionFragment returns ViolationCondition
	 *     ViolationCondition returns ViolationCondition
	 *
	 * Constraint:
	 *     conditionExpression=ConditionExpression
	 */
	protected void sequence_ViolationCondition(ISerializationContext context, ViolationCondition semanticObject) {
		if (errorAcceptor != null) {
			if (transientValues.isValueTransient(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, SmlPackage.Literals.CONDITION_FRAGMENT__CONDITION_EXPRESSION));
		}
		SequenceFeeder feeder = createSequencerFeeder(context, semanticObject);
		feeder.accept(grammarAccess.getViolationConditionAccess().getConditionExpressionConditionExpressionParserRuleCall_2_0(), semanticObject.getConditionExpression());
		feeder.finish();
	}
	
	
	/**
	 * Contexts:
	 *     InteractionFragment returns WaitCondition
	 *     ConditionFragment returns WaitCondition
	 *     WaitCondition returns WaitCondition
	 *
	 * Constraint:
	 *     (strict?='strict'? requested?='eventually'? conditionExpression=ConditionExpression)
	 */
	protected void sequence_WaitCondition(ISerializationContext context, WaitCondition semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Contexts:
	 *     ParameterExpression returns WildcardParameterExpression
	 *     WildcardParameterExpression returns WildcardParameterExpression
	 *
	 * Constraint:
	 *     {WildcardParameterExpression}
	 */
	protected void sequence_WildcardParameterExpression(ISerializationContext context, WildcardParameterExpression semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
}
