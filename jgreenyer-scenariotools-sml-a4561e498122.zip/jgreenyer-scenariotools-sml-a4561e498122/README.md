# README #



### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###
* [Summary of setup](https://bitbucket.org/jgreenyer/scenariotools-sml/wiki/Eclipse%20Setup)
* Dependencies: EMF, Xtext, Eclipse Debug, Henshin
* [How to run tests](https://bitbucket.org/jgreenyer/scenariotools-sml/wiki/JUnit%20Tests)
* Deployment instructions: TODO

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner: Joel Greenyer
* SDL editor/model: Florian König
* runtime/debug: Timo Gutjahr, Nils Glade